################################################################################
# Author:      Info2 Tutors
# MatNr:       -
# File:        __init__.py
# Description: This is the init file for the test package.
# Comments:    -
################################################################################

from pathlib import Path

TEST_DATA_DIR = Path(__file__).parent / "TEST_DATA"
